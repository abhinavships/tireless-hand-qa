## 2026-09-26T07:47:29.521261+00:00 | status: IN_PROGRESS
**Did:** Full desktop sweeps M01 and M02 complete (all registered15 spec files, findings excluded only where @finding). M04 active next. Canonical target proof folders remain untouched.
**Evidence:** `evidence/full-suite/M02/desktop/Sxx/mutant-M02`: S01 target, S08 collateral (removed Control panel link) caught; S02/S03/S04/S05(a,c)/S06/S07/S09 cockpit/S12/S13/S17 PASS. S09 dashboard/S10 failures match F3/F2 baseline; S00 baseline lacks clean3, unproven; S11 no-base skipped. M01 results previously summarized. All lock holds below5min, reversals and served-marker removal successful.
**Findings:** First2 sweeps show no independent false alarm on qualified hard checks; collateral explained by removed video/link. Same underlying defect may cause multiple scenario catches; not counted as multiple injected bugs.
**Risks / flakes:** Remaining16 desktop and2 additionalphone sweeps queued; all3-viewport completeness still0/18. Current scope18 desktop scenario sweeps plusphone responsive; master can package all18 qualified target artifacts now while collateral stage proceeds.
**Next:** M04 complete scope and classify hidden-row collateral; continue queue.

## 2026-09-26T07:43:38.588947+00:00 | status: IN_PROGRESS
**Did:** Matrix updated:18 runnable,18/18 qualified target catches; M11 baseline-only F2, M15 dropped D19. Conservative full-suite completeness compares all configured desktop/tablet/phone projects; current complete desktop M01 is explicitly a scoped sweep, not completion of all configured viewport coverage. M02 active.
**Evidence:** Fresh raw HTML paths correction: `qa/test-results/t05-M03b-1790407992-14912/html/index.html` and `qa/test-results/t05-M05b-1790408011-4875/html/index.html` (earlier prose said report; actual runner folder is html). JSON paths unchanged and verified. Auth video durations M12 12.16sec, M16 11.84sec; both canonical videos correspond to failing case. S11 clean retains each case repeat0/1/2. Typecheck PASS.
**Risks / flakes:** Full all-configured-project coverage remains0/18; present execution scope is full scenario set on desktop +phone forresponsive mutants. No all-viewports completion claim. M03b default target now S05(c), changed by atomic replacement so an already-open shell script remains intact; syntax checks PASS.
**Next:** Continue queued desktop/phone full scenario sweeps, retain precise coverage limits.

## 2026-09-26T07:41:46.833150+00:00 | status: IN_PROGRESS
**Did:** First COMPLETE full desktop spec sweep M01 finished. M02 full sweep started. Full stage configured all 18 executable mutants, desktop all 15 spec files, phone additional for M09/M09b, 7 short lock groups each. macOS Bash empty-array expansion fixed before first product apply; no lost browser run.
**Evidence:** `evidence/full-suite/M01/desktop/Sxx/mutant-M01/runs.json` across S00–S13 and S17. S01 target caught; S07/S08 collateral caught from absent video region; S02/S03/S04/S05(a,c)/S06/S09 cockpit/S12/S13/S17 PASS. S09 dashboard2 and S10 evil/missing2 fail as known F3/F2 baseline findings, no new regression. S11 skipped without auth overlay; S00 unproven (clean baseline fails), no qualified catch. Canonical targeted evidence preserved.
**Findings:** No independent false alarm demonstrated in M01; qualified collateral failures explain the removed video tile. Repeated known findings not counted as new bugs.
**Risks / flakes:** Full sweep cost about5min/mutant distributed over short individual locks (longest ~96sec). Remaining17 desktop +2 phone sweeps may take ~90min. Targeted submission-ready artifacts already complete; full-stage completion must not be claimed while queued. Master can use targeted proofs now; long collateral task continues as originally required.
**Need from master:** T07 update stale15/16 target count to18/18, fixture S11 proofs, fresh precise M05b message; all above paths available before requested07:41Z. Matrix helper clarifies baseline-only/dropped rows and reports actual full coverage.
**Next:** Remaining full-suite checks and collateral report. No commits.

## 2026-09-26T07:35:39.736907+00:00 | status: IN_PROGRESS
**Did:** ALL TARGETED PROOFS COMPLETE: 12 original P0 + M03b/M03c/M05b/M09b + auth M12/M16 = 18 distinct executable mutants caught. M11 baseline-only F2; M15 dropped D19. F-auth clean6/6 passed, two S11 cases each3, RUN_ID=t05-auth-clean. M12/M16 stacked, served, tested, reversed base+mutant; product git status clean and lock released.
**Evidence:** S11 clean `evidence/S11/clean`; M12 `evidence/S11/mutant-M12`, message “Signed-out visitor can open protected route http://localhost:4010/settings”; M16 `evidence/S11/mutant-M16`, “Operator cannot sign in: Sign in action missing”. Each folder has canonical video.webm / trace.zip / screenshot.png / runs.json / verdict.json. Raw RUN_ID paths in qa/mutations/logs/M12-targeted.log and M16-targeted.log. Fresh M03b/M05b raw paths and pre-cleanup snapshot listed immediately below.
**Findings:** Auth proof is explicitly a F-auth fixture base overlay, not a claim about upstream authentication. Prior misses are historical; latest strengthened variants both caught. T07 v2 counts are stale: 18/18 runnable mutants now caught, no current target misses.
**Risks / flakes:** Full-suite collateral stage remains incomplete, evidence/full-suite currently M01 partial. Will continue independently under short locks without overwriting targeted evidence.
**Need from master:** T07 update S11 fixture card and strengthened variant proof/count; use all canonical paths now. T04 may mark S11 paired proof complete.
**Next:** Complete full-suite sweeps per mutant; classify collateral versus baseline findings and regenerate matrix.

## 2026-09-26T07:35:12.483870+00:00 | status: IN_PROGRESS
**Did:** FRESH strengthened retests BOTH CAUGHT before ~07:41Z deadline: M03b→S05(c), M05b→S03. Each used its distinct unchanged variant, its own app.lock apply→run→revert, no retries. F-auth clean qualification completed 6/6 PASS (both S11 cases x3), RUN_ID=t05-auth-clean; M12/M16 targeted proofs now follow.
**Evidence:** M03b raw report `qa/test-results/t05-M03b-1790407992-14912/results.json`, HTML report same run/report; canonical `evidence/S05/mutant-M03b/{video.webm,trace.zip,screenshot.png,verdict.json,runs.json}`. Precise assertion: “A drone with no telemetry must show unknown/unavailable, never invented in_flight or online”; actual list `in_flight`, selected panel unknown with battery —, independently no flight telemetry, API standby. PRE-CLEANUP snapshot preserved and visually verified: `qa/test-results/t05-M03b-1790407992-14912/artifacts/S05-offline-truth-S05-c-ne-3bea7-ve-flight-telemetry-network-desktop/attachments/no-telemetry-screen-e21174eabbd89066c3a0da22e0b19f3ffef6c9e8.png` (also canonical screenshot.png).
**Evidence:** M05b raw report `qa/test-results/t05-M05b-1790408011-4875/results.json`; canonical `evidence/S03/mutant-M05b/{video.webm,trace.zip,screenshot.png,verdict.json,runs.json}`. Precise assertion: “Selected QA-7733ab3e-flying-B battery must match API for drone-195, not the previously selected drone's battery (tolerance 2%)”; observed difference 6.7 points >2. Real user-impact assertion failure after selecting A then B, not setup/infra. Raw logs `qa/mutations/logs/M03b-targeted.log`, `M05b-targeted.log`.
**Findings:** Previously missed subtle variants now detected by T03 strengthened clean3 checks; matrix regenerated with qualified catches. M03c/M09b distinct earlier catches retained. Original 12 P0 targets remain caught. Baseline findings remain separate.
**Risks / flakes:** None in fresh retests. Full-suite collateral runs remain partially complete; no complete-suite claim yet. Auth fixture proof explicitly applies to F-auth overlay, not upstream product auth.
**Need from master:** T03/T07 may consume fresh paired proof paths above immediately. No further retest needed for these two variants.
**Next:** Finish M12/M16 auth proofs; resume full-suite collateral batches, keep each lock hold <5min, always revert.

## 2026-09-26T07:30:20.250124+00:00 | status: IN_PROGRESS
**Did:** Started full scenario sweeps on desktop against matching clean3 live baselines (additional phone sweep reserved for M09), split into short groups. M01 partial full evidence now records S01 target and S07/S08 collateral catches. Paused queued full sweep between groups at a clean boundary for T03 strengthened qualification and short F-auth proof readiness. Added mutate.sh --base F-auth stacking/reversal and clean overlay mode; no-browser base probe PASS. Auth patch helper never edited product.
**Evidence:** Full evidence path evidence/full-suite/M01/desktop/Sxx/mutant-M01. M01 S00 failure lacks qualifying clean3 (explicitly unproven); S07/S08 caught*; S03/S04 pass. Targeted canonical evidence untouched. Auth clean6 is now queued under own app.lock after T03's strengthened9 batch, RUN_ID=t05-auth-clean. Base apply→served→revert probe exit0; product clean.
**Findings:** Missing-status/previous-battery misses drove T03 to real API-arranged stronger S05(c)/S03 oracles. Strengthened clean3 currently running. M03b re-test must target S05(c), not only original S05(a).
**Risks / flakes:** Full-suite project scope desktop across every scenario, plus phone sweep for responsive M09; MUTATION_PROJECTS allows tablet/phone extension. Auth canonical collector now selects the failing subtest for mutant videos and explicit signed-out context for guard recordings, avoiding unused blank default-page video. T05 private collect.ts preserves sourceSpecId and stable repeat IDs; central T01 bug still separately requested.
**Need from master:** T03 report strengthened results for immediate retests. T04 may finalize S09 paired proof: cockpit clean PASS6/6 plus M10 both payload FAIL2/2, dashboard baseline F3 artifact rows preserved without rerun. T01 still fix shared repeat fallback. Auth proving now interleaves the long collateral phase after P0 as D18 allows; full sweeps remain required work and will resume.
**Next:** Auth clean3, M12/M16; rerun M03b on S05(c) and M05b strengthenedS03 within T03 timebox; resume remaining full sweeps and regenerate final matrix.

## 2026-09-26T07:23:38.786291+00:00 | status: IN_PROGRESS
**Did:** All four requested subtle variants executed. M03c caught by S04 and S05(a); M09b caught on phone. M03b MISSED; corrected M05b MISSED. Corrected M05b bootstrap to use first selected drone until a prior selection exists; its initial prototype failed waitReady from null startup battery and was NOT accepted as wrong-source sensitivity proof. Re-run valid M05b passes with plausible previous-drone values; matrix now shows missed.
**Evidence:** M03c messages: grounded list/panel disagree with API, offline list invents in_flight. M09b message: device-row vertically clipped by ancestor and centre covered. M03b S05(a) PASS 6.3s; M05b S03 PASS 13.8s (latest valid patch), canonical evidence under respective mutant labels. Original 12 P0 mutants all remain caught with clean3.
**Findings:** Two sensitivity gaps: (1) S05 never exercises missing status because it waits for initialized telemetry; (2) S03 battery sources differ by no more than its 2-point tolerance during short flight, so previous-drone battery stays accepted while altitude/speed remain correct. No false failure forced.
**Risks / flakes:** Patch prototype boot failure superseded; don't use its first M05b artifacts. Latest evidence regenerated and product clean. Sensitive wrong-source test should arrange a deterministic battery separation greater than tolerance before switching, instead of relying on timing/flaky drift.
**Need from master:** T03 strengthen missing-status S05 coverage and wrong-source battery S03 arrangement, then request M03b/M05b retests. T04 S11 add human-readable submit visibility failure message (Operator cannot sign in: Sign in action missing) if desired before fixture proof; current generic Playwright message includes role/name but lacks summary. No product changes from helpers.
**Next:** Full-suite per-mutant collateral runs in short project groups. F-auth/M12/M16 artifacts generated and stack/reversal/syntax verified in temp only; actual auth overlay qualification after full-suite phase per D14.

## 2026-09-26T07:22:08.289362+00:00 | status: IN_PROGRESS
**Did:** Sensitivity run M03b completed: MISSED (S05(a) passes on missing-status→in_flight fallback). M03c currently running; M09b/M05b follow. All 12 original P0 targets remain caught/qualified.
**Evidence:** evidence/S05/mutant-M03b/{video.webm,trace.zip,screenshot.png,runs.json,verdict.json}; 1 passed, 6.3s. Matrix M03b→S05 = missed with matching clean3.
**Findings:** Coverage gap: S05(a) starts after waitReady/retained flight status exists, so it never observes a missing-status state. M03b only changes that fallback; known initialized statuses remain correct. This is a genuine slipped mutant, not a fake assertion failure.
**Risks / flakes:** A missing-status check needs deterministic absent flight_status (e.g. controlled browser socket payload suppression while retaining fleet), rather than a transient race before normal telemetry arrives. T05 does not own T03 specs and has not modified them.
**Need from master:** T03 harden S05 to exercise unknown/missing flight status and reject active in_flight claims without supporting telemetry, then notify T05 for M03b rerun. Master asked to report slips; this is the first. No P0 original proof regression.
**Next:** Finish other subtle variants; full-suite collateral runs. Auth artifact helper is building F-auth/M12/M16 from clean HEAD without touching product, now original P0 proofs complete.

## 2026-09-26T07:21:38.622581+00:00 | status: IN_PROGRESS
**Did:** ALL 12 P0 TARGETED MUTANTS QUALIFIED CAUGHT: M01/M02→S01, M04→S02, M09→S08 phone, M13→S12, M14→S13, M03→S05(a), M05→S03, M06→S04, M07→S06, M08→S07, M10→S09 cockpit. T03 repaired its own clean manifests; all hard scenarios now have actual clean x3. Added T05-private repeat-aware collect.ts for own future auth qualification; shared T01 collector remains untouched.
**Evidence:** evidence/Sxx/mutant-Mxx canonical video.webm/trace.zip/screenshot.png and verdict/runs; mutation-matrix.md shows caught in every targeted P0 cell. Additional clean S09 cockpit qualification via supported lock-held run.sh PASS6/6 (two payload classes x3, 18.5s), RUN_ID=t05-s09-cockpit-qualification. Re-collected distinct repeat 0/1/2 from retained raw reports using own collector and merged retained dashboard F3 rows/artifacts back. No dashboard re-execution. All product edits reverted, product git status clean.
**Findings:** F1/F2/F3 remain baseline findings, excluded from regression claims. M10 failure: Stored XSS in cockpit operator session. M06 wrong standby phase, M07 falsely connected badge, M08 stopped stream labelled live all caught precisely.
**Risks / flakes:** Shared collector stable-key fix still requested from T01. Other workers' repaired manifests are valid; private collect.ts gives T05 safe repeated auth collection. Full-suite collateral runs and subtle variants not yet complete.
**Need from master:** T02/T03/T04 may now finalize paired cards from proof paths. T01 fix central repeat fallback as already requested; no browser rerun needed. T04 third-priority finding work can proceed; T05 will keep each later variant/full-suite hold short.
**Next:** Four sensitivity variants; all-project full-suite collateral runs in short groups with separate EVIDENCE_ROOT; then F-auth/M12/M16 fixture clean/proof. Auth artifact helper works only on patch files now that P0 proof is complete; no helper touches product.

## 2026-09-26T07:17:47.646789+00:00 | status: IN_PROGRESS
**Did:** M01/M02/M04/M09 targeted proofs caught with matched qualified clean baseline. M13 currently running; M14 and live-data targets follow. Every patch reversed and clean served state polled between runs; no product edits outside locks.
**Evidence:** M01→S01 "operator cannot reach Video tile"; M02→S01 "operator cannot reach Control panel action"; M04→S02 "Initial fleet: operators must see every API drone with its correct name and paired dock within 5 seconds"; M09→S08 phone "Operator must scroll horizontally: content 1040px exceeds viewport 390px". Canonical video/trace/screenshot and verdicts in evidence/Sxx/mutant-Mxx; matrix shows caught.
**Findings:** none new; known F1/F2/F3 separate.
**Risks / flakes:** T02 repaired its clean repeat identities from raw reports. Latest T03 clean S03–S07 manifests still repeat [0,0,0], so their catches will remain unproven in matrix until re-collected correctly (raw 15/15 PASS does exist).
**Need from master:** URGENT T01 stable-title/file/project repeat counter fix remains outstanding. T03 can normalize/recollect its retained raw t03-qualified2 report as T02 did, preserving unique artifacts/repeats 0,1,2. No browser rerun needed. T04 will need final S09 cockpit 3x manifests for M10 proof; finding videos have D20 third priority.
**Next:** Finish T02 targets then M03/M05/M06/M07/M08/M10; let T04 third-priority videos run, then sensitivity/full-suite/auth work.

## 2026-09-26T07:13:22.167050+00:00 | status: IN_PROGRESS
**Did:** Audited latest clean manifests and discovered collector repeat-index regression. Browser qualification remains passing, but latest evidence rows lose distinct repeat identity.
**Evidence:** evidence/S01/clean/runs.json has 9 passed rows, but desktop repeats are [0,0,0] (same for tablet/phone). latest T01 evidence.ts keys fallback repeat counts by spec.id-project; Playwright repeat specs have distinct ids, so the counter resets each time. Artifact basenames collide and matrix conservatively demotes S01 from 3x to <3x. Raw qa/test-results/t02-s01-final/results.json retains all real runs, so no new browser execution is required to repair collection.
**Findings:** Collector issue, not product bug. M01 still visibly caught but matrix qualification awaits correct re-collection.
**Risks / flakes:** Upcoming T03 15-run collector uses same code; it will also record [0,0,0] unless fixed before collection. Latest S09 collector currently similarly uses 0 per repeat class.
**Need from master:** URGENT T01 fix repeats key to stable file/title/project (not spec.id), preserve a unique source spec id in each run, then re-collect RUN_ID=t02-s01-final RUN_LABEL=clean (all artifacts retained). This will also avoid filename collision. Matrix needs actual distinct repeats; do not relax qualification to hide bug.
**Next:** Continue queued mutation proofs after T03; regenerate matrix after corrected manifests.

## 2026-09-26T07:09:55.626443+00:00 | status: IN_PROGRESS
**Did:** Read new D20 lock priority; cancelled T05's M02 queue while it was still only waiting (no patch applied), yielding next slot to T03 final qualification. M01 qualified proof retained. All product files clean.
**Evidence:** M01 catch with canonical video/trace/screenshot; others pending. T05 owns no current lock or browser process.
**Findings:** none new.
**Risks / flakes:** T06 current soak segment 2 still owns lock; master D20 says pause exploration. T05 will not compete until T03 15-test qualification completes.
**Need from master:** nothing beyond D20 enforcement. T03 please update report when its final qualification is complete so T05 starts targeted proofs immediately.
**Next:** Read T03 results, run M02/M04/M09/M13/M14 then M03/M05/M06/M07/M08/M10 under short locks; continue variants/full-suite/auth after priorities satisfied.

## 2026-09-26T07:08:57.761425+00:00 | status: IN_PROGRESS
**Did:** Targeted queue remains active; M01 is the first qualified catch. T02 final known-state clean qualification now 33 PASS/0 FAIL. Full-suite evidence aggregation implemented with actual links, separate baseline failure assessment and per-project counts; separate EVIDENCE_ROOT preserves targeted artifacts.
**Evidence:** M01 S01 caught; screenshot visually verified (FPV absent, remaining cockpit usable). M02 has not applied yet; waiting since 07:07:04Z.
**Findings:** Scheduling conflict: T06 acquired soak segment 2 at 07:08:33Z immediately after segment 1 despite queued T03 P0 qualification and T05 proofs. No product changes currently active.
**Risks / flakes:** Root mutex lacks FIFO fairness; segmented soak immediately reacquires, starving D14 P0 work. T05 changed acquisition wait to 20min (no lock held while waiting), preventing false timeout evidence. Browser runs still hold only brief per-mutant slots.
**Need from master:** Please pause further T06 soak segments after current release so T03 clean qualification and T05 P0 proof can run in D14 order. T03 same request in its report. No owner bypass or manual borrowed token used.
**Next:** Finish queued T02 targets, T03/T04 targets, subtle sensitivity runs, full-suite segmented project passes, then F-auth/M12/M16.

## 2026-09-26T07:05:29.504671+00:00 | status: IN_PROGRESS
**Did:** M01 targeted S01 desktop caught with precise message. T05 mutation batch M02/M04/M09/M13/M14 is queued; each releases lock after revert. Added sensitivity variants and suffix matrix support; T01 now accepts suffix labels and EVIDENCE_ROOT.
**Evidence:** evidence/S01/mutant-M01/video.webm, trace.zip, screenshot.png, verdict.json; failure: "Cockpit: operator cannot reach Video tile". Matrix M01→S01 caught (clean matching x3). Product restored clean.
**Findings:** No new product findings. Subtle M03b missing-status coverage may slip because S05 waits for initialized telemetry; M05b plausible wrong-source battery may slip if tolerance exceeds battery differences. Will execute and report, not predeclare.
**Risks / flakes:** Current holder codex-t04 T06 soak segment 1 (07:05:13Z), so P0 proofs waiting behind stretch exploration. Task D14 requests targeted P0 first after qualifications.
**Need from master:** Please prioritize P0 mutation proof slots over further T06 soak segments once current segment releases. T03/T04 clean qualification completion needed before their catches can count. All mutant browser batches use app.lock and child borrowing; no other owner lock touched.
**Next:** Finish targeted T02 batch, then T03/T04, then full spec suites and auth overlay per D18.

## 2026-09-26T07:04:22.818944+00:00 | status: IN_PROGRESS
**Did:** M01 targeted browser proof is now RUNNING under T05-owned app.lock, validated child borrowing. Master-requested variants generated; no product source edits outside runner.
**Evidence:** M01 no-browser probe PASS. Earlier queued M01 shell was interrupted by my edits to the live script (syntax-read offset); no patch was applied, but it left an empty acquired directory. Removed only that empty T05 lock, reran bash -n, restarted stable script. No scripts will be edited while active now.
**Findings:** T02 legacy parent-lock script cannot satisfy new globalSetup without token; urgent request remains.
**Risks / flakes:** All proof batches serialized via lock; no mutant failures claimed until evidence collected and matched to 3x clean.
**Need from master:** T01 variant RUN_LABEL regex support remains needed. T02 use run.sh for final S01 arrangement requalification.
**Next:** M02/M04/M09/M13/M14 targeted one lock hold each.

## 2026-09-26T07:03:37.362820+00:00 | status: IN_PROGRESS
**Did:** M01 --probe PASS: source applied, executable marker served through Vite, patch reversed, clean source served, product clean. Targeted M01 queued behind current owner. Generated M03b/M03c/M09b/M05b subtle variants (clean HEAD reads only); matrix accepts suffix variants. All browser proofs remain lock-held.
**Evidence:** Probe exit 0; product clean. M01 browser batch waiting.
**Findings:** URGENT T02 current /tmp/t02-s01-final.sh acquires app.lock but supplies NO token; new Playwright globalSetup waits on that same parent lock. Owner codex-t02 S01 isolated-state qualification since 07:02:33Z, token file absent. This batch cannot qualify until T02 stops its own shell and reruns with run.sh or token. T05 has NOT touched another worker lock.
**Risks / flakes:** Nested legacy-runner deadlock is coordination, not product failure. T05 queued lock deadline 180s.
**Need from master:** Notify T02 to replace /tmp/t02-s01-final.sh with D15 tools/run.sh. T01 add variant label regex mutant-M[0-9]+[a-z]? to run.sh/evidence.ts. D18 F-auth follows P0 proof.
**Next:** T02 mapped proofs, then qualified T03/T04 mutants and variants; full suite per executable mutant.

## 2026-09-26T07:02:00.514013+00:00 | status: IN_PROGRESS
**Did:** Re-read D12–D19 and task response; T01 D15 reported implemented. Resuming with app.lock for every run; removed old pgrep runner refusal since D16 mutex defines the slot. Added --probe for authorized no-browser M01 apply→served→revert check.
**Evidence:** Pending probe, then T02 targeted proofs after clean lock releases.
**Findings:** D19 M11 baseline-only/M15 dropped; D18 F-auth + stacked M12/M16 deferred until P0 proofs complete.
**Risks / flakes:** Variant labels M03b/M03c/M09b/M05b need harness evidence label support.
**Need from master:** T01 please allow mutant-M[0-9]+[a-z]? labels in run.sh/evidence.ts for master's requested subtle variants (T05 will use exact variant IDs and extend matrix). T03 clean qualification still pending; will avoid overwriting clean labels.
**Next:** Probe M01 without browser; run qualified T02 mutants individually, then qualified T03/T04 set; create subtle variants and report misses.

## 2026-09-26T06:50:37.991630+00:00 | status: BLOCKED
**Did:** Completed qa/mutations/M01–M15 metadata/patches, reproducible read-only build.py, README, concrete lock-borrowing request, guarded mutate.sh and evidence-driven matrix.ts. Runner audit fixed cleanup cwd, explicit multifile sync failure handling, served-clean marker removal polling, multiscenario grep, and preflight refusal during active Playwright/nested-lock incompatibility. Matrix excludes baseline/synthetic patches and recognized infrastructure failures.
**Evidence:** qa typecheck PASS; bash -n PASS; Python AST parse PASS; all 14 executable diffs git apply --check PASS. evidence/mutation-matrix.md generated. M01 initial apply/sync/revert verified product clean, but Vite comment readiness failed before tests; executable marker retry remains untested. NO mutant UI catches claimed. Clean S01/S08 entries currently include the earlier invalid overlap, not established product failures.
**Findings:** T04 confirmed M11 is baseline org-isolation defect, so no removable guard; M12 synthetic lacks real baseline auth requirement (drop recommended). T03 reports M15 unsupported geospatial oracle (S14 dropped recommended). M10 targets cockpit; dashboard XSS already exists on clean baseline.
**Risks / flakes:** Full mutant suite cannot safely execute until T01 adds token-validated parent lock borrowing. T02 currently owns app.lock for clean evidence; T03 clean batch also pending/restart. Shared run.sh output requires exclusive batch slot. Initial overlapping T02 clean batch is invalid and needs its planned rerun.
**Need from master:** T01 implement qa/mutations/lock-borrowing-request.md in owned qa/lib/fixtures.ts. Designate T05 mutation window after clean qualification; notify other workers to stop clean browser runs during it. Confirm dropped M12/S11 and M15/S14; preserve M11/S10 baseline evidence. No user approval needed, just owner coordination.
**Next:** Once prerequisite is resolved, run M01/M02/S01, M04/S02, M09/S08 phone, M13/S12, M14/S13 targeted first; then M03/M05/M06/M07/M08/M10 and full hard suite for every executable mutant, regenerate matrix. Expected mutant failures are evidence, not runner errors. No commits; product clean and no T05-owned lock remains.

## 2026-09-26T06:48:22.132992+00:00 | status: IN_PROGRESS
**Did:** All mutants generated; M14 adjusted to T02 request (unnamed dashboard Start button). Matrix helper qa/tools/matrix.ts completed and generated evidence/mutation-matrix.md. Stopped queued M01 retry to avoid invalidating T02/T03 clean runs. Product is clean.
**Evidence:** M01 first readiness attempt reverted safely without browser test: Vite strips comment markers. Changed readiness to executable JS metadata/CSS custom property; pending safe runner slot. Matrix currently records unproven/missing honestly.
**Findings:** M11 baseline unguarded socket; M12 baseline lacks protected routes; M15 no observable entity surface/spec from T03. These cannot count as proven catches yet.
**Risks / flakes:** T02 reports its clean batch collided with first mutation. That batch must be rerun. T03 also reports overlapping shared results. No mutation browser batch has executed yet.
**Need from master:** URGENT T01 shared helper changes: acquireAppLock must borrow parent lock only if APP_LOCK_TOKEN equals app.lock/token; no-op borrowed release. Also unique runner output/report path per process (config + evidence.ts), OR explicit exclusive QA runner slot. Master please designate mutation window after clean batches. T04 needs M12 route overlay or classify synthetic unsupported. Other workers: T05 paused pending safe runner slot.
**Next:** Document mutants and resume mutation batches after shared runner/lock prerequisite resolved. All product mutations always reverted; no commits.

## 2026-09-26T06:46:53.119925+00:00 | status: IN_PROGRESS
**Did:** Generated M01–M15 patch metadata in qa/mutations; 14 applicable diffs pass git apply --check. Added guarded qa/tools/mutate.sh (compose cp + HTTP marker polling + trap reversal; full suite by default, --targeted optional). Matrix helper is implementing qa/tools/matrix.ts.
**Evidence:** bash -n qa/tools/mutate.sh PASS; git apply checks PASS; stack health connected/up. Pending browser execution.
**Findings:** M11 already exists in clean backend: socket subscribe/handshake have no org-id validation. M11 is BASELINE_ONLY, never fabricated as caught. M12 synthetic /settings route requires T04 contract configuration before it can prove a guard.
**Risks / flakes:** Global mutation suite will deadlock on fault fixtures until token borrowing support arrives. All patch files carry an HTTP-visible marker to prove served sync.
**Need from master:** URGENT T01: add acquireAppLock borrowing only when APP_LOCK_TOKEN equals app.lock/token; borrowed release must be no-op. T04: M12 /settings synthetic route exists but routes.json baseline declares no protected route: request opt-in contract overlay to run S11 against known signed-out denial baseline, or drop M12 as unsupported. T02/T03 please avoid clean evidence runs while mutation lock is held.
**Next:** Run non-global targeted mutation first, then full suites once harness lock reuse is available.

## 2026-09-26T06:45:10.107905+00:00 | status: IN_PROGRESS
**Did:** Read protocol 00–04, decisions and T05 brief; claimed task after T01 NEEDS_REVIEW.
**Evidence:** Pending.
**Findings:** none yet.
**Risks / flakes:** Shared global runtime requires mutation runner to share its held lock safely with scenario fixtures.
**Need from master:** T01: add token-validated lock borrowing to acquireAppLock for mutation children (APP_LOCK_TOKEN must equal app.lock/token; borrowed release is no-op). T05 runner must hold app.lock while locked fault specs run. M11 org guard already absent in clean source; request baseline-finding proof rather than artificial catch.
**Next:** Inspect sources and requests; build M01–M15 and runner, then execute available scenarios.
